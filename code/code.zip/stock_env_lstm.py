""" 
The environment simulates the possibility of buying or selling a good. The agent can either have one unit or zero unit of that good. At each transaction with the market, the agent obtains a reward equivalent to the Price of the good when selling it and the opposite when buying. In addition, a penalty of 0.5 (negative reward) is added for each transaction.
Two actions are possible for the agent:
- Action 0 corresponds to selling if the agent possesses one unit or idle if the agent possesses zero unit.
- Action 1 corresponds to buying if the agent possesses zero unit or idle if the agent already possesses one unit.
The state of the agent is made up of an history of two punctual observations:
- The Price signal
- Either the agent possesses the good or not (1 or 0)
The Price signal is build following the same rules for the training and the validation environment. That allows the agent to learn a strategy that exploits this successfully.

Authors: Vincent Francois-Lavet, David Taralla
"""

import numpy as np
from mpl_toolkits.axes_grid1 import host_subplot
import mpl_toolkits.axisartist as AA
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
import pandas as pd

import time

import theano
import copy

from deer.base_classes import Environment

from stock_data import data_series


obs = 60

class MyEnv(Environment):
    
    
    def __init__(self, rng):
        """ Initialize environment.

        Parameters
        -----------
            rng : the numpy random number generator
        """
        self._epoch = 0
        #start = "2004-01-02"
       # end = "2016-07-12"     
        self._run_date = time.strftime("%m%d%Y-%H%M")
        
        # Building a Price signal with some patterns
#        data = pd.DataFrame(data_series(start, end))
        data = pd.read_csv('tcehy_new.csv')
        data = ((data.iloc[:,:] - data.mean().values)/data.std().values).dropna(axis=1, how='all').dropna(how='any')
        
        self.variables = len(data.columns)
                
        # Defining the type of environment
        self._last_ponctual_observation = [np.zeros(self.variables)] # At each time step, the observation is made up of two elements, each scalar
        self._random_state = rng
        
        train_split = len(data.index)-obs-1
                        
        self.data_train, self.data_validation = data[:train_split], data[train_split:]        
        
        print("Using %s data points for training and %s data points for validation." % (len(self.data_train.index), len(self.data_validation.index)))
        
        self._counter = 1   
        
        self._cash = 100000
        self._positions = 0
        self._wealth = [self._cash]
                
    def reset(self, mode):
        
        if mode == -1:
            self.data = pd.DataFrame(self.data_train)
            self._mode = "training"
            self._epoch += 1

        else:
            self.data = pd.DataFrame(self.data_validation)
            self._mode ="validation"
        
        self._last_ponctual_observation = [0, 0]
        for col in self.data.columns.values:
            self._last_ponctual_observation.append(self.data.loc[self.data.index[0], col])
        self._counter = 1
        
        self._cash = 100000
        self._positions = 0
        self._wealth = [self._cash]
        
        plt.close("all")
        
        initial = [0, 0]
        for i in range(self.variables):
            initial.append(np.zeros((obs,), dtype=np.int))
        
        return initial
        
        
    def act(self, action):
        reward = 0
        #batch = 10000
        lot = 50
        cost = 5      
        
        #hold
        if (action == 0):
             reward = 0
             
        #buy
        if (action == 1 and self._cash > 0):
        #if (action == 1):
            #self._cash -= int(batch / self.data.loc[self.data.index[self._counter], 'Price']) * self.data.loc[self.data.index[self._counter], 'Price'] + cost
            #self._positions += int(batch / self.data.loc[self.data.index[self._counter], 'Price'])
            self._cash -= self.data.loc[self.data.index[self._counter], 'Price'] * lot - cost
            self._positions += lot
        
            
        #sell    
        if (action == 2 and self._positions > -500):
            self._cash += self.data.loc[self.data.index[self._counter], 'Price'] * lot - cost
            self._positions -= lot
        
        #cover short
        if (action == 3 and self._positions < 0):
            self._cash += self.data.loc[self.data.index[self._counter], 'Price'] * self._positions - cost
            self._positions = 0
        
        #sell all
        if (action == 4 and self._positions > 0):
            self._cash += self.data.loc[self.data.index[self._counter], 'Price'] * self._positions - cost
            self._positions = 0
            
            
        self._wealth.append(self.data.loc[self.data.index[self._counter], 'Price'] * self._positions + self._cash)
        reward = self._wealth[self._counter] - self._wealth[self._counter-1]
        
        self._last_ponctual_observation[0] = action
        #self._last_ponctual_observation[1] = self._cash
        self._last_ponctual_observation[1] = self._positions
        #self._last_ponctual_observation[3] = self._wealth[self._counter]
        
        for i in range(self.variables):
            self._last_ponctual_observation[i+2] = self.data.iloc[self._counter, i]
        
        if self._counter % 100 == 0 and self._mode == "training":
            print("Step %s - Wealth: %s | Cash: %s | Positions: %s | Reward: %s" % (self._counter, '${:,.0f}'.format(self._wealth[self._counter]), '${:,.0f}'.format(self._cash), '{:,.0f}'.format(self._positions), '{:,.0f}'.format(reward)))
        
        if self._counter % 18 == 0 and self._mode == "validation":
            print("Step %s - Wealth: %s | Cash: %s | Positions: %s | Reward: %s" % (self._counter, '${:,.0f}'.format(self._wealth[self._counter]), '${:,.0f}'.format(self._cash), '{:,.0f}'.format(self._positions), '{:,.0f}'.format(reward)))
        
        #print(self._last_ponctual_observation)        
        
        self._counter += 1
        
        return reward

    def summarizePerformance(self, test_data_set):
        """
        This function is called at every PERIOD_BTW_SUMMARY_PERFS.
        Parameters
        -----------
            test_data_set
        """
        print ("Summary Perf")
        
        observations = test_data_set.observations()
        print(observations)
        pd.DataFrame(observations).to_csv('logs' + self._run_date + '_debug.csv')
        Prices = observations[5][:]
        actions = pd.DataFrame(observations[0][:])
        positions = observations[1][:]
        
        t = np.arange(len(Prices))
        x = Prices
        z = np.array(positions)
        
        colors = {0: "blue" , 1: "green", 2: "red"}
        y = actions.applymap(colors.get)
        y = y[0].values.tolist()
        
        z_pos = z > 0
        z_neg = z < 0

        plt.title("Epoch %s - Wealth %s" % (self._epoch, '${:,.0f}'.format(self._wealth[obs])))         
        ax1 = plt.subplot(111)
        ax2 = ax1.twinx()
        ax1.scatter(t,x,c=y,s=3, lw=0.05, alpha=1).set_zorder(10)
        #ax1.legend(loc=0, shadow=True, title="Actions", fancybox=True)
        ax1.plot(t, x, lw=0.5, alpha=0.5)
        yl = ax1.get_ylim()
        ax1.set_ylim(yl[0]-(yl[1]-yl[0])*0.15,yl[1])
        ax1.set_ylabel("Prices", size=7)
        ax1.set_xlabel("Steps", size=7)
        ax1.grid(True, alpha=0.1)
        ax1.set_axisbelow(True)
        ax1.spines["top"].set_visible(False)
        ax1.spines["bottom"].set_visible(False)
        ax1.spines["right"].set_visible(False)
        ax1.spines["left"].set_visible(False)
        ax1.xaxis.set_ticks_position('none')
        ax1.yaxis.set_ticks_position('none')
        ax1.tick_params(axis='both', which='major', labelsize=4)
        ax1.tick_params(axis='both', which='minor', labelsize=3)
        
        ax2.patch.set_visible(True)
        ax2.set_position(matplotlib.transforms.Bbox([[0.125,0.1],[0.9,0.25]]))
        ax2.bar(t[z_pos],z[z_pos],color='green',lw=0.1, align='center', alpha=0.5)
        ax2.bar(t[z_neg],-1 * z[z_neg], color='red',lw=0.1, align='center', alpha=0.5)
        #high = max(abs(round(min(positions)//10 - 1)) * 10, abs(round(max(positions)//10 + 1)) * 10)
        ax2.set_xlim(0, obs)
        #ax2.yaxis.set_ticks(np.arange(-1 * high , high, round(high/3,-1)))
        ax2.xaxis.set_ticks(np.arange(0,obs, 18))
        ax2.set_ylabel("Positions", size=7)
        ax2.grid(True, alpha=0.1)
        #ax2.set_axisbelow(True)
        ax2.spines["top"].set_visible(False)
        ax2.spines["bottom"].set_visible(False)
        ax2.spines["right"].set_visible(False)
        ax2.spines["left"].set_visible(False)
        ax2.xaxis.set_ticks_position('none')
        ax2.yaxis.set_ticks_position('none')
        ax2.tick_params(axis='both', which='major', labelsize=4)
        ax2.tick_params(axis='both', which='minor', labelsize=3)
        
        # Legend
        # Create fake labels for legend
        l1 = Line2D([], [], color="white", marker='o', markeredgewidth=0.05, markersize=2, markerfacecolor='b')
        l2 = Line2D([], [], color="white", marker='o', markeredgewidth=0.05, markersize=2, markerfacecolor='g')
        l3 = Line2D([], [], color="white", marker='o', markeredgewidth=0.05, markersize=2, markerfacecolor='r')
         
        labels = ["Hold", "Buy", "Sell"]
         
        # Position legend in lower right part
        # Set ncol=3 for horizontally expanding legend
        leg = ax1.legend([l1, l2, l3], labels, ncol=1, frameon=False, fontsize=5, 
                        bbox_to_anchor=[1.1, 0.6], handlelength=2, 
                        handletextpad=1, columnspacing=0, title='Actions', numpoints=1)
         
        # Customize legend title
        # Set position to increase space between legend and labels
        plt.setp(leg.get_title(), fontsize=6, alpha=1)
        leg.get_title().set_position((0, 10))
        # Customize transparency for legend labels
        [plt.setp(label, alpha=1) for label in leg.get_texts()]        
        
        plt.savefig('logs/' + self._run_date + '_plot.png', dpi=500)
        print ("A plot of the policy obtained has been saved under the name plot.png")
            
    def inputDimensions(self):
        inputs = [(1,), (1,), (1,), (1,), (1,)]
        for i in range(self.variables-3):
            inputs.append((obs,))
        return inputs    # We consider an observation made up of an history of 
                                # - the last six for the first scalar element obtained
                                # - the last one for the second scalar element


    def nActions(self):
        return 3                # The environment allows two different actions to be taken at each time step


    def inTerminalState(self):
        return False

    def observe(self):
        return np.array(self._last_ponctual_observation)
        
                


def main():
    # Can be used for debug purposes
    rng = np.random.RandomState(123456)
    myenv = MyEnv(rng)

    print (myenv.observe())
    
if __name__ == "__main__":
    main()
