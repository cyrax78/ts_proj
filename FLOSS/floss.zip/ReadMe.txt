# The package contains the source code for the paper:   
# "Domain Agnostic Online Semantic Segmentation"

# runSegmentation Function can be used for CAC calculation
# sample usage of that is:
# CAC = runSegmentation(timeseries, subsequence_length)
#
# You can also use the following functions:
# flussScore.m, humanScoresonDatasets.m, randomVsFluss.m
# In each script the path of file should be set